package com.example.jadwali

data class Lesson(
    val day: String,
    val period: Int,
    val subject: String,
    val start: String,
    val end: String
)
