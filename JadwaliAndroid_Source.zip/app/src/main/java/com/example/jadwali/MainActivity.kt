package com.example.jadwali

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface

class MainActivity : Activity() {
    private val purple = Color.rgb(112, 72, 180)
    private val pale = Color.rgb(246, 241, 255)
    private lateinit var content: LinearLayout
    private var selectedDay = Store.days.first()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pale)
            setPadding(18, 24, 18, 18)
        }
        val title = TextView(this).apply {
            text = "جدولي 📚"
            textSize = 28f
            setTextColor(purple)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 18)
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "جدولك الأسبوعي • ٧ حصص يوميًا"
            textSize = 15f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 12)
        }
        root.addView(subtitle)
        val daySpinner = Spinner(this)
        daySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Store.days)
        daySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedDay = Store.days[position]
                refreshLessons()
            }
        }
        root.addView(daySpinner)
        val add = Button(this).apply {
            text = "+ إضافة حصة"
            setTextColor(Color.WHITE)
            setBackgroundColor(purple)
            setOnClickListener { showAddDialog() }
        }
        root.addView(add)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 10, 0, 10) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val note = TextView(this).apply {
            text = "لإظهار الويدجت: اضغط مطولًا على الشاشة الرئيسية ← الأدوات (Widgets) ← جدولي."
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(8, 12, 8, 4)
        }
        root.addView(note)
        setContentView(root)
        refreshLessons()
    }

    private fun refreshLessons() {
        if (!::content.isInitialized) return
        content.removeAllViews()
        val lessons = Store.load(this).filter { it.day == selectedDay }.sortedBy { it.period }
        if (lessons.isEmpty()) {
            content.addView(TextView(this).apply {
                text = "لا توجد حصص مضافة ليوم $selectedDay بعد.\nاضغط «إضافة حصة» للبدء."
                textSize = 17f; gravity = Gravity.CENTER; setTextColor(purple); setPadding(16, 30, 16, 30)
            })
        }
        lessons.forEach { lesson ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.WHITE)
                setPadding(16, 12, 16, 12)
            }
            val line = TextView(this).apply {
                text = "الحصة ${lesson.period}  •  ${lesson.subject}"
                textSize = 18f; setTextColor(purple); typeface = Typeface.DEFAULT_BOLD
            }
            val time = TextView(this).apply {
                text = "${lesson.start} – ${lesson.end}"
                textSize = 15f; setTextColor(Color.DKGRAY); setPadding(0, 4, 0, 0)
            }
            card.addView(line); card.addView(time)
            card.setOnClickListener { showEditDialog(lesson) }
            val lp = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 6, 0, 6) }
            content.addView(card, lp)
        }
    }

    private fun showAddDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 8, 20, 0) }
        val subject = EditText(this).apply { hint = "اسم المادة" }
        val period = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                (1..7).map { "الحصة $it" })
        }
        val start = EditText(this).apply { hint = "وقت البداية (مثال 08:00)"; setSingleLine() }
        val end = EditText(this).apply { hint = "وقت النهاية (مثال 08:45)"; setSingleLine() }
        box.addView(TextView(this).apply { text = "اليوم: $selectedDay"; setTextColor(purple); textSize = 16f })
        box.addView(subject); box.addView(period); box.addView(start); box.addView(end)
        AlertDialog.Builder(this).setTitle("إضافة حصة").setView(box)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ") { _, _ ->
                val name = subject.text.toString().trim()
                if (name.isNotEmpty()) {
                    val all = Store.load(this)
                    val p = period.selectedItemPosition + 1
                    all.removeAll { it.day == selectedDay && it.period == p }
                    all.add(Lesson(selectedDay, p, name,
                        start.text.toString().ifBlank { "—" }, end.text.toString().ifBlank { "—" }))
                    Store.save(this, all)
                    refreshLessons()
                } else Toast.makeText(this, "اكتب اسم المادة أولًا", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showEditDialog(lesson: Lesson) {
        AlertDialog.Builder(this)
            .setTitle("${lesson.subject} • الحصة ${lesson.period}")
            .setItems(arrayOf("تعديل الحصة", "حذف الحصة")) { _, which ->
                if (which == 0) {
                    selectedDay = lesson.day
                    val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 8, 20, 0) }
                    val subject = EditText(this).apply { setText(lesson.subject); hint = "اسم المادة" }
                    val start = EditText(this).apply { setText(lesson.start); hint = "وقت البداية" }
                    val end = EditText(this).apply { setText(lesson.end); hint = "وقت النهاية" }
                    box.addView(subject); box.addView(start); box.addView(end)
                    AlertDialog.Builder(this).setTitle("تعديل الحصة").setView(box)
                        .setNegativeButton("إلغاء", null)
                        .setPositiveButton("حفظ") { _, _ ->
                            val all = Store.load(this)
                            all.removeAll { it.day == lesson.day && it.period == lesson.period }
                            all.add(lesson.copy(subject = subject.text.toString().ifBlank { lesson.subject },
                                start = start.text.toString().ifBlank { lesson.start },
                                end = end.text.toString().ifBlank { lesson.end }))
                            Store.save(this, all); refreshLessons()
                        }.show()
                } else {
                    val all = Store.load(this)
                    all.removeAll { it.day == lesson.day && it.period == lesson.period }
                    Store.save(this, all); refreshLessons()
                }
            }.show()
    }
}
