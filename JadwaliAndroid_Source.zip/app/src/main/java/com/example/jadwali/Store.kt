package com.example.jadwali

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Store {
    val days = listOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس")
    private const val PREFS = "jadwali_prefs"
    private const val KEY = "lessons"

    fun load(context: Context): MutableList<Lesson> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return mutableListOf()
        return try {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Lesson(o.getString("day"), o.getInt("period"), o.getString("subject"),
                    o.getString("start"), o.getString("end"))
            }
        } catch (_: Exception) { mutableListOf() }
    }

    fun save(context: Context, lessons: List<Lesson>) {
        val arr = JSONArray()
        lessons.forEach { l ->
            arr.put(JSONObject().put("day", l.day).put("period", l.period)
                .put("subject", l.subject).put("start", l.start).put("end", l.end))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
        TimetableWidget.updateAll(context)
    }
}
