package com.example.jadwali

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class TimetableWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, TimetableWidget::class.java))
            ids.forEach { updateOne(context, manager, it) }
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_timetable)
            val lessons = Store.load(context).sortedWith(compareBy<Lesson>({ Store.days.indexOf(it.day) }, { it.period }))
            val lines = if (lessons.isEmpty()) {
                "أضف حصصك من تطبيق جدولي"
            } else {
                Store.days.joinToString("\n\n") { day ->
                    val dayLessons = lessons.filter { it.day == day }
                    if (dayLessons.isEmpty()) "$day: لا توجد حصص"
                    else "$day\n" + dayLessons.joinToString("\n") { l ->
                        "${l.period}. ${l.subject}  ${l.start}-${l.end}"
                    }
                }
            }
            views.setTextViewText(R.id.widget_content, lines)
            val intent = Intent(context, MainActivity::class.java)
            val pending = android.app.PendingIntent.getActivity(
                context, 0, intent,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pending)
            manager.updateAppWidget(id, views)
        }
    }
}
